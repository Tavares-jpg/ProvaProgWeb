﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace ProvaProgWeb.DAO
{
    public class PersonagemDAO
    {
        public static List<Personagem> ListarPersonagens()
        {
            using (RPGGameEntities contexto = new RPGGameEntities())
            {
                var lista = contexto.Personagem
                                    .Include("Classe")
                                    .Include("Raca")
                                    .ToList();
                return lista;
            }
        }

        public static string CadastrarPersonagem(Personagem personagem)
        {
            try
            {
                using (RPGGameEntities contexto = new RPGGameEntities())
                {
                    contexto.Personagem.Add(personagem);
                    contexto.SaveChanges();
                    return "Personagem cadastrado com sucesso!";
                }
            }
            catch (Exception ex)
            {
                return "Erro ao cadastrar: " + ex.Message;
            }
        }
    }
}