﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProvaProgWeb.DAO
{
    public class ClasseDAO
    {
        public static List<Classe> ListarClasses()
        {

            using (RPGGameEntities contexto = new RPGGameEntities())
            {

                return contexto.Classe.ToList();
            }
        }
    }
}
