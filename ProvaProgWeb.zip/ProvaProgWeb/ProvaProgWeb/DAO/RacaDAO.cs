﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProvaProgWeb.DAO
{
    public class RacaDAO
    {
        public static List<Raca> ListarRacas()
        {
            using (RPGGameEntities contexto = new RPGGameEntities())
            {
                return contexto.Raca.ToList();
            }
        }
    }
}