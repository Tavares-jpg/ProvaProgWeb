﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using ProvaProgWeb.DAO;

namespace ProvaProgWeb 
{
    public partial class FrmPersonagem : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                CarregarDropDowns();
                CarregarPersonagens();
            }
        }

        private void CarregarPersonagens()
        {
            List<Personagem> lista = PersonagemDAO.ListarPersonagens();

            lvPersonagens.DataSource = lista;
            lvPersonagens.DataBind();
        }

        private void CarregarDropDowns()
        {
            ddlClasse.DataSource = ClasseDAO.ListarClasses();
            ddlClasse.DataTextField = "Descricao";
            ddlClasse.DataValueField = "Id";
            ddlClasse.DataBind();
            ddlClasse.Items.Insert(0, new ListItem("Selecione uma Classe...", ""));

            ddlRaca.DataSource = RacaDAO.ListarRacas();
            ddlRaca.DataTextField = "Descricao";
            ddlRaca.DataValueField = "Id";
            ddlRaca.DataBind();
            ddlRaca.Items.Insert(0, new ListItem("Selecione uma Raça...", ""));
        }

        protected void btnSalvar_Click(object sender, EventArgs e)
        {
            try
            {
                Personagem p = new Personagem();
                p.Nome = txtNome.Text;
                p.Nivel = Convert.ToInt32(txtNivel.Text);
                p.ClasseId = Convert.ToInt32(ddlClasse.SelectedValue);
                p.RacaId = Convert.ToInt32(ddlRaca.SelectedValue);

                string mensagem = PersonagemDAO.CadastrarPersonagem(p);

                lblMensagem.Text = mensagem;
                lblMensagem.CssClass = "mensagem-sucesso";

                CarregarPersonagens();
                LimparCampos();
            }
            catch (Exception ex)
            {
                lblMensagem.Text = "Erro ao salvar: " + ex.Message;
                lblMensagem.CssClass = "mensagem-erro";
            }
        }

        private void LimparCampos()
        {
            txtNome.Text = "";
            txtNivel.Text = "";
            ddlClasse.SelectedIndex = 0;
            ddlRaca.SelectedIndex = 0;
        }
    }
}